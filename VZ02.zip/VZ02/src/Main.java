import controller.GameplayController;
import maincharacter.hero.Hero;
import maincharacter.player.Player;
import stage.Stage;
import world.World;
import view.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * Created by axelinate on 4/23/17.
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        ViewMainMenu.buildViewGame();
    }
}
