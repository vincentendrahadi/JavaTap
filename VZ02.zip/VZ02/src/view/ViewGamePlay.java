package view;

import controller.EnemyController;
import controller.GameplayController;
import controller.HeroController;
import controller.PlayerController;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import maincharacter.hero.Hero;
import maincharacter.player.Player;
import stage.Stage;
import world.World;

/**
 * <h2>ViewShop.java</h2>
 * Kelas ViewShop sebagai view dari Shop.
 *
 * @author adit
 * @since 2017-04-22
 */
public class ViewGamePlay extends JFrame {

  private static JPanel panelGamePlay = new JPanel();
  private static JPanel panelIdlePlayer = new JPanel();
  private static JButton shop = new JButton("Shop");
  private static JFrame frameMain = new JFrame("GamePlay");
  private static JLabel idlePlayer;
  private static JLabel attackPlayer;
  private static JLabel enemyNotHurt;
  private static JLabel enemyHurt;
  private static JLabel joyHero;
  private static JLabel sadnessHero;
  private static JLabel angerHero;
  private static JLabel disgustHero;
  private static JLabel fearHero;
  private static JLabel money = new JLabel("Money  : ");
  private static JLabel currMoney = new JLabel("0");
  private static JLabel attack = new JLabel("Attack  : ");
  private static JLabel currAttack = new JLabel();
  public static JLabel level = new JLabel("Level  : ");
  public static JLabel currLevel = new JLabel();

  private static JTextField dummy = new JTextField();
  private static JProgressBar progressbar = new JProgressBar();
  private static JProgressBar countdown = new JProgressBar();

  public static Player p;
  public static PlayerController pc;
  public static Hero h;
  public static HeroController hc;
  public static ArrayList<Hero> hero;
  public static Stage stages;
  public static int curStage;
  public static EnemyController ec;
  public static World world;
  public static GameplayController gc;

  private static boolean enterTimeBoss = false;
  private static boolean haveBuiltShop = false;

  /**
   * Setter visible menjadi true untuk label hero Anger.
   */
  public static void setAngerHero() {
    angerHero.setVisible(true);
  }

  /**
   * Setter visible menjadi true untuk label hero Joy.
   */
  public static void setJoyHero() {
    joyHero.setVisible(true);
  }

  /**
   * Setter visible menjadi true untuk label hero Sadness.
   */
  public static void setSadnessHero() {
    sadnessHero.setVisible(true);
  }

  /**
   * Setter visible menjadi true untuk label hero Disgust.
   */
  public static void setDisgustHero() {
    disgustHero.setVisible(true);
  }

  /**
   * Setter visible menjadi true untuk label hero Fear.
   */
  public static void setFearHero() {
    fearHero.setVisible(true);
  }

  /**
   * Inisiasi untuk health bar pada enemy yang sedang dihadapi.
   */
  public static void viewBar() {
    panelGamePlay.add(progressbar);
    progressbar.setBounds(500, 10, 400, 30);
    progressbar.setStringPainted(true);
    progressbar.setForeground(Color.GREEN);
    progressbar.setValue(100);

    // progressbar.setValue(progressbar.getMinimum());
  }

  /**
   * Prosedur yang digunakan untuk menampilkan timer pada layar ketika melawan boss.
   */
  public static void viewTimeBoss() {
    if (!enterTimeBoss) {
      enterTimeBoss = true;
      panelGamePlay.add(countdown);
      countdown.setBounds(0, 0, 400, 30);
      countdown.setStringPainted(true);
      countdown.setForeground(Color.LIGHT_GRAY);

      countdown.setValue(100);
      countdown.setStringPainted(true);
      Timer executionTime = new Timer();
      executionTime.scheduleAtFixedRate(new TimerTask() {
        private int index = 0;
        private int maxIndex = 100;

        @Override
        public void run() {
          if (ec.getEnemyModel().isBoss()) {
            if (maxIndex >= index) {
              countdown.setValue(maxIndex);
              maxIndex = maxIndex - 10;
            } else {
              enterTimeBoss = false;
              countdown.setValue(index);
              executionTime.cancel();
            }
          } else {
            enterTimeBoss = false;
            executionTime.cancel();
          }
        }
      }, 10, 900);
      //countdown.setValue(countdown.getMinimum());
    }

  }

  /**
   * Menginisiasi model serta controller yang digunakan dalam game.
   *
   * @param filename file dimana stage enemy disimpan.
   * @throws FileNotFoundException jika file tidak ditemukan.
   */
  public static void initiateController(String filename) throws FileNotFoundException {
    curStage = 0;
    p = new Player("Player");
    pc = new PlayerController(p);
    hero = new ArrayList<>();
    stages = new Stage(filename);
    ec = new EnemyController(stages.getCurEnemy());
    world = new World(p, hero, stages);
    gc = new GameplayController(world);
    p.plusMoney(100000);
    gc.addWorldHero();
  }

  /**
   * Melakukan build komponen pada Layar,
   * serta menjalankan program threading yang ada.
   *
   * @throws FileNotFoundException jika file tidak ditemukan.
   */
  public static void buildViewGamePlay() throws FileNotFoundException {
    try {
      int t = ec.getModelHealth();
    } catch (NullPointerException e) {
      initiateController("stage.txt");

    }

    frameMain.setSize(1366, 768);
    frameMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    panelGamePlay.setLayout(null);
    panelGamePlay.setBackground(Color.gray);

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/KeyboardSmasher/src/res/idlePlayer.png"));
      ImageIcon icon = new ImageIcon(img);
      idlePlayer = new JLabel(icon);
      idlePlayer.setBounds(550, 300, 400, 400);
      panelGamePlay.add(idlePlayer);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/KeyboardSmasher/src/res/attackingPlayer.png"));
      ImageIcon icon = new ImageIcon(img);
      attackPlayer = new JLabel(icon);
      attackPlayer.setBounds(450, 300, 400, 400);
      panelGamePlay.add(attackPlayer);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/KeyboardSmasher/src/res/idleEnemy.png"));
      ImageIcon icon = new ImageIcon(img);
      enemyNotHurt = new JLabel(icon);
      enemyNotHurt.setBounds(580, 50, 250, 250);
      panelGamePlay.add(enemyNotHurt);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/KeyboardSmasher/src/res/hurtEnemy.png"));
      ImageIcon icon = new ImageIcon(img);
      enemyHurt = new JLabel(icon);
      enemyHurt.setBounds(580, 50, 250, 250);
      panelGamePlay.add(enemyHurt);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    ////////////////////////////////////////////////////////
    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/VZ02/src/res/hero1.jpg"));
      ImageIcon icon = new ImageIcon(img);
      joyHero = new JLabel(icon);
      joyHero.setBounds(1000, 450, 150, 150);
      panelGamePlay.add(joyHero);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/VZ02/src/res/hero2.jpg"));
      ImageIcon icon = new ImageIcon(img);
      sadnessHero = new JLabel(icon);
      sadnessHero.setBounds(1100, 150, 150, 150);
      panelGamePlay.add(sadnessHero);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/VZ02/src/res/hero3.jpg"));
      ImageIcon icon = new ImageIcon(img);
      angerHero = new JLabel(icon);
      angerHero.setBounds(70, 120, 150, 150);
      panelGamePlay.add(angerHero);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/VZ02/src/res/hero4.jpg"));
      ImageIcon icon = new ImageIcon(img);
      disgustHero = new JLabel(icon);
      disgustHero.setBounds(200, 320, 150, 150);
      panelGamePlay.add(disgustHero);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    try {
      BufferedImage img = ImageIO
              .read(new File("/home/adit/IdeaProjects/VZ02/src/res/hero5.jpg"));
      ImageIcon icon = new ImageIcon(img);
      fearHero = new JLabel(icon);
      fearHero.setBounds(320, 520, 150, 150);
      panelGamePlay.add(fearHero);
    } catch (IOException ex) {
      ex.printStackTrace();
    }

    /////////////////////////////////////////////////////////////////////////////

    viewBar();

    attackPlayer.setVisible(false);
    enemyHurt.setVisible(false);
     joyHero.setVisible(false);
    sadnessHero.setVisible(false);
    angerHero.setVisible(false);
    disgustHero.setVisible(false);
    fearHero.setVisible(false);

    money.setForeground(Color.YELLOW);
    money.setBounds(1106, 10, 300, 30);
    money.setFont(new Font("", Font.BOLD, 20));

    currMoney.setForeground(Color.YELLOW);
    currMoney.setBounds(1216, 11, 300, 30);
    currMoney.setFont(new Font("", Font.BOLD, 20));

    level.setForeground(Color.BLACK);
    level.setBounds(1106, 51, 300, 30);
    level.setFont(new Font("", Font.BOLD, 20));

    currLevel.setForeground(Color.BLACK);
    currLevel.setBounds(1216, 51, 300, 30);
    currLevel.setFont(new Font("", Font.BOLD, 20));
    currLevel.setText("0");

    attack.setForeground(Color.RED);
    attack.setBounds(1106, 91, 300, 30);
    attack.setFont(new Font("", Font.BOLD, 20));

    currAttack.setForeground(Color.RED);
    currAttack.setBounds(1216, 91, 300, 30);
    currAttack.setFont(new Font("", Font.BOLD, 20));

    panelGamePlay.add(countdown);
    panelGamePlay.add(currMoney);
    panelGamePlay.add(money);
    panelGamePlay.add(level);
    panelGamePlay.add(currLevel);
    panelGamePlay.add(attack);
    panelGamePlay.add(currAttack);
    panelGamePlay.add(shop);
    panelGamePlay.add(dummy);
    shop.setBounds(1166, 665, 200, 53);
    frameMain.getContentPane().add(ViewGamePlay.getPanelGamePlay());
    frameMain.setVisible(true);

    dummy.addKeyListener(new KeyListener() {
      @Override
      public void keyTyped(KeyEvent e) {

      }

      @Override
      public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
          enemyNotHurt.setVisible(false);
          enemyHurt.setVisible(true);
          attackPlayer.setVisible(true);
          idlePlayer.setVisible(false);
        }
      }

      @Override

      public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
          if (ec.getModelHealth() > 0) {
            pc.attackEnemy(ec);
            System.out.println("Enemy : " + ec.getEnemyModel().getName());
            System.out.println("Enemy : " + ec.getEnemyModel().getCurHealth());
          }
          enemyNotHurt.setVisible(true);
          enemyHurt.setVisible(false);
          attackPlayer.setVisible(false);
          idlePlayer.setVisible(true);
          pc.plusModelMoney(pc.getModelAttPower());
        }
      }
    });
    Double temp;
    runThread();
    new ViewGamePlay();
  }

  /**
   * Mengeset agar dummy panel sebagai penerima input enter menjadi fokus pada window.
   */
  public static void focusKey() {
    dummy.requestFocusInWindow();
  }

  /**
   * Menjalankan thread hero yang ada sesuai dengan countHero.
   */
  public static void runThread() {
    SwingWorker swingWork = new SwingWorker() {
      @Override
      protected Object doInBackground() throws Exception {
        while (!isCancelled()) {
          Timer execution = new Timer();
          execution.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
              if (((int) (((float) ec.getEnemyModel().getCurHealth() / (float) ec.getEnemyModel()
                      .getMaxHealth()) * 100)) >= 0) {
                progressbar.setValue((int) (
                        ((float) ec.getEnemyModel().getCurHealth() / (float) ec.getEnemyModel()
                                .getMaxHealth()) * 100));
              } else {
                progressbar.setValue(0);
              }
              currMoney.setText(String.valueOf(pc.getModelMoney()));
              currAttack.setText(String.valueOf(pc.getModelAttPower()) + " (" + String.valueOf(
                      new DecimalFormat("##.##").format(
                              ((float) pc.getModelAttPower() / (float) ec.getEnemyModel().getMaxHealth())
                                      * 100) + "%" + ")"));
              currLevel.setText(String.valueOf(ViewGamePlay.pc.getModelLevel()));
              ViewShop.moneyCapacity.setText(String.valueOf(pc.getModelMoney()));

              if (ec.getEnemyModel().isBoss()) {
                countdown.setVisible(true);
                viewTimeBoss();
              } else {
                //executionTime.cancel();
                //executionTime.purge();
                countdown.setVisible(false);
              }
            }
          }, 10, 1);


          int cur = stages.getCurStage();
          gc.setWorldMonster();

          while (cur < gc.getWorldStage().getGameStage().size()) {
            for (int i = 0; i < gc.getWorldHeroCount(); i++) {
              System.out.println(gc.getWorldHero(i).getThreadName());
              gc.getWorldHero(i).start();
            }
            System.out.println(gc.getWorldHeroCount());
            synchronized (gc.getWorldHero(0).getHeroThread()) {
              try {
                gc.getWorldHero(0).getHeroThread().wait();
                gc.getWorldPlayer().plusMoney(ec.getModelMoneyLoot());
                System.out.println("Money : " + gc.getWorldPlayer().getMoney());
                cur++;
                //System.out.println("BBBBBBBBBB" + cur);
                gc.getWorldStage().setCurStage(cur);
                gc.getWorldHero(0).getHeroThread().sleep(1);
              } catch (InterruptedException e) {
                System.out.println("World Interrupted");
              }
            }
            gc.setWorldThreadToNull();
            gc.setWorldMonster();
            ec.setEnemyModel(gc.getWorldCurEnemy());
          }
          cancel(true);
        }
        return null;
      }
    };
    swingWork.execute();
  }

  public static void setFrameMain(JFrame frameMain) {
    ViewGamePlay.frameMain = frameMain;
  }

  public static JFrame getFrameMain() {
    return frameMain;
  }

  public static void setShop(JButton shop) {
    ViewGamePlay.shop = shop;
  }

  public static JButton getShop() {
    return shop;
  }

  public static void setPanelGamePlay(JPanel panelGamePlay) {
    ViewGamePlay.panelGamePlay = panelGamePlay;
  }

  /**
   * Getter panel game play pada layar.
   *
   * @return JPanel.
   */
  public static JPanel getPanelGamePlay() {
    return panelGamePlay;
  }

  /**
   * Konstruktor untuk view game play.
   *
   * @throws FileNotFoundException jika file tidak ditemukan.
   */
  public ViewGamePlay() throws FileNotFoundException {
    shop.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        frameMain.setVisible(false);
        if (!haveBuiltShop) {
          try {
            ViewShop.buildViewShop();
            haveBuiltShop = true;
          } catch (FileNotFoundException e1) {
            e1.printStackTrace();
          }
        } else {
          ViewShop.getFrameShop().setVisible(true);
        }
      }
    });
  }
}